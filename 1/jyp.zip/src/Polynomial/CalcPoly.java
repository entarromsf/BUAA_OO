package Polynomial;

import java.util.Arrays;
import java.util.Scanner;
import java.util.regex.*;

public class CalcPoly {
	//data
	private Poly[] polyList = new Poly[20];
	private int[] opList = new int[20];
	private int num;
	private static boolean mark = true;
	
	//constructors
	public CalcPoly()
	{
		;
	}
	
	//methods
	private void parse(String s)
	{
		int i = 0;
		num = 0;
		for(int j=0;j<s.length();j++)
			if(s.charAt(j) == '}')
				num++;
		if(num>20)
		{
			System.err.println("ERROR\n#Error type4");
			mark = false;
			return;
		}
		for(int j=0;j<num;j++)
		{
			polyList[i] = new Poly();
		}
		String[] PolyTerms = s.split("}");
		if(PolyTerms.length>50)
		{
			System.err.println("ERROR\n#Error type5");
			mark = false;
			return;
		}
		for(String tmp : PolyTerms)
		{
			Poly tmpPoly = new Poly();
			if(tmp.charAt(0) == '{' || tmp.charAt(0) == '+')
				opList[i] = 1;
			else if(tmp.charAt(0) == '-')
				opList[i] = -1;
			
			String regex = "([+-]?[0-9]{1,6}),([+-]?[0-9]{1,6})";
			Pattern r = Pattern.compile(regex);
			Matcher m = r.matcher(tmp);
			while (m.find())
			{
				int n = Integer.parseInt(m.group(1));
				//tmp.replaceFirst(m.group(1), "");
				int x = Integer.parseInt(m.group(2));
				if(x<0)
				{
					System.err.println("ERROR\n#Error type1");
					mark = false;
					return;
				}
				//tmp.replaceFirst(m.group(1), "");	
			    if(!tmpPoly.InitPoly(n,x))
			    	{
			    		System.err.println("ERROR\n#Error type2");
			    		mark = false;
			    		return;
			    	}
			}
			polyList[i++] = tmpPoly;
		}		
		
	}
	
	private boolean judgePoly(String s)
	{		
		int i = 0;
		int len = s.length();
		int mark = 0;
		int NumCount = 0;
		while (i < len)
		{
			switch (mark)
			{
			case -2:
			{
				if (s.charAt(i) == '{')
					mark = 1;
				else 
					mark = -1;
				i++;
				break;
			}
			case -1:
			{
				return false;
			}
			case 0:
			{
				NumCount = 0;
				if (s.charAt(i) == '{')
					mark = 1;
				else if(s.charAt(i) == '-'||s.charAt(i) == '+')
					mark = -2;
				else
					mark = -1;
				i++;
				break;
			}
			case 1:
			{
				NumCount = 0;
				if (s.charAt(i) == '(')
					mark = 2;
				else
					mark = -1;
				i++;
				break;
			}
			case 2:
			{
				NumCount = 0;
				if (s.charAt(i) == '+' || s.charAt(i) == '-')
					mark = 3;
				else if (s.charAt(i) >= '0'&&s.charAt(i) <= '9')
					mark = 4;
				else
					mark = -1;
				i++;
				break;
			}
			case 3:
			{
				NumCount = 0;
				if (s.charAt(i) >= '0'&&s.charAt(i) <= '9')
					mark = 4;
				else
					mark = -1;
				i++;
				break;
			}
			case 4:
			{
				NumCount++;
				if(NumCount>6)
				{
					mark = -1;
					return false;
				}
				if (s.charAt(i) >= '0'&&s.charAt(i) <= '9')
					mark = 4;
				else if (s.charAt(i) == ',')
					mark = 5;
				else
					mark = -1;
				i++;
				break;
			}
			case 5:
			{
				NumCount = 0;
				if (s.charAt(i) == '+' || s.charAt(i) == '-')
					mark = 6;
				else if (s.charAt(i) >= '0'&&s.charAt(i) <= '9')
					mark = 7;
				else
					mark = -1;
				i++;
				break;
			}
			case 6:
			{
				NumCount = 0;
				if (s.charAt(i) >= '0'&&s.charAt(i) <= '9')
					mark = 7;
				else
					mark = -1;
				i++;
				break;
			}
			case 7:
			{
				NumCount++;
				if(NumCount>6)
				{
					mark = -1;
					return false;
				}
				if (s.charAt(i) >= '0'&&s.charAt(i) <= '9')
					mark = 7;
				else if (s.charAt(i) == ')')
					mark = 8;
				else
					mark = -1;
				i++;
				break;
			}
			case 8:
			{
				NumCount = 0;
				if (s.charAt(i) == ',')
					mark = 1;
				else if (s.charAt(i) == '}')
					mark = 9;
				else
					mark = -1;
				i++;
				break;
			}
			case 9:
			{
				NumCount = 0;
				if (s.charAt(i) == '+' || s.charAt(i) == '-')
					mark = 10;
				else
					mark = -1;
				i++;
				break;
			}
			case 10:
			{
				NumCount = 0;
				if (s.charAt(i) == '{')
					mark = 1;
				else
					mark = -1;
				i++;
				break;
			}
			}
		}
		if (mark == 9)
			return true;
		else
			return false;
	}
	
	
	private void calc()
	{
		Poly p = new Poly(); 
		p =	polyList[0];
		if(opList[0] == -1)
			p.minus();
		Poly p1 = new Poly();
		for(int i=1;i<num;i++)
		{
			p1 = polyList[i];
			int op = opList[i];
			if(op == 1)
				p.add(p1);
			else if(op== -1)
				p.sub(p1);
		}
		
		p.print();
		
	}
	
	public static void main(String args[])
	{
		//input s
		Scanner scan = new Scanner(System.in);
		String tmp = scan.nextLine();
		String s = tmp.replaceAll(" ", "");
		scan.close();
							
		CalcPoly cp = new CalcPoly();
		if(!cp.judgePoly(s))
			{
				System.err.println("ERROR\n#Error type3");
				return;
			}		
		cp.parse(s);
		if(!mark)
			return;
		cp.calc();
	}
}
