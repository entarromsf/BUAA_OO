package Polynomial;

public class Poly {
	//data
	private int[] terms;
	private int degree;
	
	//constructors
	public Poly()
	{
		terms = new int[1000000];
		degree = 0;
	}
	
	public Poly(int n, int x)
	{
		if(x > degree)
			degree = x;
		terms[x] = n;
	}
	
	public Poly(int x)
	{
		degree = x;
		terms = new int[degree+1];
	}
	
	//methods
	public int GetCoeff(int x)
	{
		return terms[x];
	}
				
	public boolean InitPoly(int c, int x)
	{
		if(x>1000000)
			return false;
		else 
		{
			if(terms[x]!=0)
				return false;
			terms[x] = c;
			return true;
		}
	}
	
	public void minus()
	{
		for(int i=0;i<100000;i++)
			this.terms[i] = -this.terms[i];
	}
	
	public void sub(Poly q)
	{
		Poly large, small;
		for(int i=0;i<1000000;i++)
		{
			this.terms[i] = this.terms[i] - q.terms[i];
		}
	}
	
	public void add(Poly q)
	{
		Poly large, small;
		for(int i=0;i<1000000;i++)
		{
			this.terms[i] = this.terms[i] + q.terms[i];
		}
	}
	
	public void print()
	{
		int mark = 0;
		int count = 0;
		for(int i=0;i<1000000;i++)
		{
			if(this.GetCoeff(i)!=0)
				{mark = 1;count++;}
		}
		if(mark == 0)
			System.out.println("0");
		else 
		{
			System.out.print("{");
			int countTmp = 0;
			for(int i=0;i<1000000;i++)
			{
				if(this.GetCoeff(i)!=0)
					{
						System.out.print("("+this.GetCoeff(i)+","+i+")");
						countTmp++;
						if(countTmp != count)
							System.out.print(",");
					}
			}
			System.out.println("}");
		}
	}
	
}
